<?php
$nombre = "Andrés";
$apellido1 = "López";
$apellido2 = "Barrera";
$email = "andreslb2000@gmail.com";
$anoNacimiento = 2000;
$movil = "628856631";

echo "<table border='8'>
        <tr>
            <th>Nombre</th>
            <th>Primer Apellido</th>
            <th>Segundo Apellido</th>
            <th>Email</th>
            <th>Año de Nacimiento</th>
            <th>Móvil</th>
        </tr>
        <tr>
            <td>$nombre</td>
            <td>$apellido1</td>
            <td>$apellido2</td>
            <td>$email</td>
            <td>$anoNacimiento</td>
            <td>$movil</td>
        </tr>
      </table>";
?>