<?php
echo "<ul>";
for ($i = 0; $i <= 50; $i += 2) {
    echo "<li>$i</li>";
}
echo "</ul>";
?>
