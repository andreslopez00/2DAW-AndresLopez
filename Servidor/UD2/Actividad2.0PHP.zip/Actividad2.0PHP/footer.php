<footer>
        <p>Tu supermercado de confianza</p>
    </footer>
</body>
</html>