<?php
echo "<p>Primera frase</p>";
print "<p>Segunda frase</p>";
print_r("<p>Tercera frase</p>");

/* 
Hola Olga.
Pero y este pavo?.
*/

// Oc rinconero
?>
