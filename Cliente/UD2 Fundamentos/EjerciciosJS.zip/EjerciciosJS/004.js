"use strict";
function verificarEdad() {
    let edad = 3;
    if (edad >= 18) {
        alert("Es mayor de edad");
    } else {
        alert("Es menor de edad");
    }
}
