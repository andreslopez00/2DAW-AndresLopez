"use strict";
function mostrarNumeros() {
    let i = 1;
    while (i <= 10) {
        console.log(i);
        i++;
    }
}
mostrarNumeros()