"use strict";
function verificarMayuscula() {
    let cadena = "hola Olga";
    if (cadena.charAt(0) === cadena.charAt(0).toUpperCase()) {
        alert("Empieza con mayúscula");
    } else {
        alert("No empieza con mayúscula");
    }
}
