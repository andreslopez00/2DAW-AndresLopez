"use strict";
function compararNumeros() {
    let a = 45;
    let b = 123;
    if (a > b) {
        console.log("El mayor es: " + a);
    } else if (b > a) {
        console.log("El mayor es: " + b);
    } else {
        console.log("Los números son iguales");
    }
}
compararNumeros()