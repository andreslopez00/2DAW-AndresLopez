"use strict";
function perimetroRectangulo() {
    let largo = 6;
    let ancho = 12;
    let perimetro = 2 * (largo + ancho);
    console.log("El perímetro del rectángulo es: " + perimetro);
}
perimetroRectangulo()