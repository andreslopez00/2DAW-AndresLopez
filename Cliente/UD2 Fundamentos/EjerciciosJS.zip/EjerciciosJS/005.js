"use strict";
function juntarCadenas() {
    let nombre = "Andres";
    let apellido = "Lopez";
    let ciudad = "Sevilla";
    let mensaje = nombre + " " + apellido + ", " + ciudad;
    alert(mensaje);
}
