"use strict";
function compararNombres() {
    let nombre1 = "Manolo";
    let nombre2 = "OC";
    if (nombre1 === nombre2) {
        alert("Los nombres coinciden");
    } else {
        alert("Los nombres no coinciden");
    }
}