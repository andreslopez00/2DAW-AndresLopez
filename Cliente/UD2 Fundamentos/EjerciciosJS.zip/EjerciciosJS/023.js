"use strict";
function compararLongitudes() {
    let cadena1 = "Hola Olga";
    let cadena2 = "Sale garrin?";
    if (cadena1.length > cadena2.length) {
        console.log("La primera cadena es más larga.");
    } else if (cadena1.length < cadena2.length) {
        console.log("La segunda cadena es más larga.");
    } else {
        console.log("Las cadenas tienen la misma longitud.");
    }
}
compararLongitudes()
