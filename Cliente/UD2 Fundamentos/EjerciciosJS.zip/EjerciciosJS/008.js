"use strict";
function numeroCadena() {
    let numero = 567878;
    let mensaje = numero.toString() + " es un número grande";
    alert(mensaje);
}

