"use strict";
function comprobarParImpar() {
    let numero = 345;
    if (numero % 2 === 0) {
        alert("El número " + numero + " es par.");
    } else {
        alert("El número " + numero + " es impar.");
    }
}
