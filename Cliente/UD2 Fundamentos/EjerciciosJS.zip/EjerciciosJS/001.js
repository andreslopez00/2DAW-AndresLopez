"use strict";
function sumaNumeros() {
    let num1 = 23;
    let num2 = 103;
    let num3 = 38;
    var resultado = num1 + num2 + num3;
    alert("El resultado de la suma es: " + resultado);
}
