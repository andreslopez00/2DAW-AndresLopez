"use strict";
function sumarNumeros() {
    let numero1 = prompt("Ingresa el primer número:");
    let numero2 = prompt("Ingresa el segundo número:");
    let suma = Number(numero1) + Number(numero2);
    alert("La suma es: " + suma);
}