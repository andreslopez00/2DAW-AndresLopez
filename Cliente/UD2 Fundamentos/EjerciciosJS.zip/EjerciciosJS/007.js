"use strict";
function areaTriangulo() {
    let base = 10;
    let altura = 5;
    let area = (base * altura) / 2;
    alert("El área del triángulo es: " + area);
}
