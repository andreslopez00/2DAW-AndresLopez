"use strict";
function multiplicar() {
    let x = 10;
    let y = 23;
    let producto = x * y;
    console.log("El resultado de la multiplicación es: " + producto);
}
multiplicar()