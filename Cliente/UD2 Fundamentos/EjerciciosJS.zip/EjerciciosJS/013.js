"use strict";
function inversoLogico() {
    let verdadero = true;
    console.log("El valor inverso es: " + !verdadero);
}
inversoLogico()